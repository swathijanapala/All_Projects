'''
#!/bin/bash

read -p "Enter start date (day-month-year): " START_DATE
read -p "Enter end date (day-month-year): " END_DATE

{
  for file in ../Timeline_news/*.txt; do
      python3 mapper.py "$file" "$START_DATE" "$END_DATE" &
  done
  wait
} | python3 reducer.py > result.txt
'''
s='1-2-3'
a,b,c=s.split('-')
print(a)
print(b)
print(c)